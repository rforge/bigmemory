check_timeout <-
function(timeout)
{
  if (timeout <= 0)
    stop("The mutex timeout should be greater than 0")
}

