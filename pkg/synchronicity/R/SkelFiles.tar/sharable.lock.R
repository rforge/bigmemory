sharable.lock <-
structure(function(m, name)
  standardGeneric('sharable.lock')
, generic = structure("sharable.lock", package = ".GlobalEnv"), package = ".GlobalEnv", group = list(), valueClass = character(0), signature = c("m", 
"name"), default = <S4 object of class structure("MethodsList", package = "methods")>, skeleton = quote(function (m, 
    name) 
stop("invalid call in method dispatch to \"sharable.lock\" (no default method)", 
    domain = NA)(m, name)), class = structure("standardGeneric", package = "methods"))
