sharable.unlock <-
structure(function(m, name)
  standardGeneric('sharable.unlock')
, generic = structure("sharable.unlock", package = ".GlobalEnv"), package = ".GlobalEnv", group = list(), valueClass = character(0), signature = c("m", 
"name"), default = <S4 object of class structure("MethodsList", package = "methods")>, skeleton = quote(function (m, 
    name) 
stop("invalid call in method dispatch to \"sharable.unlock\" (no default method)", 
    domain = NA)(m, name)), class = structure("standardGeneric", package = "methods"))
