uuid <-
function()
{
  return(.Call('boost_create_uuid'))
}

